# Contributors

They helped [develop the app](https://github.com/lwouis/alt-tab-macos/graphs/contributors):

* [adamnemecek](https://github.com/adamnemecek)
* [AfzalivE](https://github.com/AfzalivE)
* [akx](https://github.com/akx)
* [ayroblu](https://github.com/ayroblu)
* [Calinou](https://github.com/Calinou)
* [damonpam](https://github.com/damonpam)
* [decodism](https://github.com/decodism)
* [gcbw](https://github.com/gcbw)
* [gingerr](https://github.com/gingerr)
* [GrzegorzKazana](https://github.com/GrzegorzKazana)
* [hughlilly](https://github.com/hughlilly)
* [i0ntempest](https://github.com/i0ntempest)
* [karbassi](https://github.com/karbassi)
* [L1cardo](https://github.com/L1cardo)
* [lwouis](https://github.com/lwouis)
* [metacodes](https://github.com/metacodes)
* [mnin](https://github.com/mnin)
* [nella17](https://github.com/nella17)
* [notlmn](https://github.com/notlmn)
* [phungtuanhoang1996](https://github.com/phungtuanhoang1996)
* [rbnis](https://github.com/rbnis)
* [Rjevski](https://github.com/Rjevski)
* [ryenus](https://github.com/ryenus)
* [s4na](https://github.com/s4na)
* [samdenty](https://github.com/samdenty)
* [skolj](https://github.com/skolj)
* [xanathar](https://github.com/xanathar)
* [xconverge](https://github.com/xconverge)
* [zacharee](https://github.com/zacharee)

They helped [localize the app](https://poeditor.com/join/project/8AOEZ0eAZE):

* 73
* Aamirsuleman
* Aarni Koskela
* Abdulelah
* Aden Aziz
* Admin
* Albert Abdilim
* Alex
* Alexander Kilian
* Ali Gokmen
* Ali. tas103
* Allen Guan
* Ameng
* Andrew Vader
* Anurag Roy
* anushree b
* Arman
* Artem Stankov
* Arthur
* Ash
* blanorama
* bluefirex
* bovirus
* caduellery
* Caner İlhan
* Christian Keilmann
* Chun Fei Lung
* Cong Tri
* Dan
* Dan84
* Darko
* David R
* David Süle
* Didier Deschrijver
* Dzhuneyt
* EDUARDO
* edu_sombra
* Eliezer Shpigelman
* Emil Pedersen
* Eric WANTZ
* Ersagun Kuruca
* Eukarya
* Eyelly wu
* fabifabulousity
* Filipe
* Frangarciasalomon
* Frank
* Friendship1
* Gezimos
* Giang
* Github
* Gkostov
* Grzegorz Kazana
* Guillaume
* hann-solo
* Haoshuai Xu
* Hjörtur Hjartarson
* Hokuto Kato
* Huandngoc
* Ialiendeg
* Ida Bomholt Dyrholm Jacobsen
* Igor Aradski
* Indexerrowaty
* isametry
* Ismatulla
* Isthereanybody
* Jaeyong Sung
* Jakob
* Jakob Licina
* Jakub Bartušek
* jiho4
* Jisan
* Joao Vitor Casarin
* Jord Nijhuis
* Jules Beckers
* Julian Nowaczyk
* Julio
* Kagurazaka Tsuki
* kal
* kant
* Kevinsevinche
* Kinyagulovrr
* Klara
* Kushnee5
* Lakshman Kolappan
* Lcwhhh
* Lester
* Loïc 
* LostInCompilation
* Lumaxis
* lwouis
* Maplevantablack
* Marc Pla
* Marcus Billman
* Marekscholle
* Marko McLion
* Martin Mitka
* Martin. mitka
* Martinjnilsen
* Masih
* Max
* Maximilian Falk
* MaximilianFreitag
* Michael
* Milos M
* Mohammad Al Zouabi
* Mr. axel. bock
* MuDraconis
* Muzhenstudent
* Mwolfinspace
* Nathancodes
* Nikola Rajić
* Nils Fahldieck
* Nilton Souza
* Nmolham
* Ori
* Pehovorka
* Peterkim0620
* Petr Kolář
* Piotr Budny
* ponchik
* Quentin. douarre
* Raphaël
* Rasmus
* Raymonf
* raz
* Razvan
* rbnis
* Roccobot
* Ron Nuss
* sawtooth
* Selcuk Dursun
* Sergey
* Seyedparsa Mirtaheri
* Shameem Reza
* SheNeVmerla
* Shivam Bansal
* shlomo
* Stan Smits
* stas
* Stefan
* Svetoslav Stefanov
* Thomas Wölk
* Thorsten
* Tomoa Nozawa
* Umutakkaya1996
* Vadym
* Vegard
* Vijayant Saini
* Vincent Orback
* Vlad
* Webmaster
* Wesley Matos
* Whatsmine-HaoshuaiXu
* Wilhelm Wolfgang Gärtner
* Wowpapa3232
* Yossi Zahn
* ysaito
* Yukai
* yumechan
* Yusuf Caliskan
* 橙梓
* Ивайло
* Андрій Кирбаба
